"""Partly Copyed from JDE code"""

# from numpy_indexed import intersection
import numpy as np
import scipy
from scipy.spatial.distance import cdist
import lap

from cython_bbox import bbox_overlaps as bbox_ious
import kalman_filter
import math 
import nn_APG
from icecream import ic

def merge_matches(m1, m2, shape):
    O,P,Q = shape
    m1 = np.asarray(m1)
    m2 = np.asarray(m2)

    M1 = scipy.sparse.coo_matrix((np.ones(len(m1)), (m1[:, 0], m1[:, 1])), shape=(O, P))
    M2 = scipy.sparse.coo_matrix((np.ones(len(m2)), (m2[:, 0], m2[:, 1])), shape=(P, Q))

    mask = M1*M2
    match = mask.nonzero()
    match = list(zip(match[0], match[1]))
    unmatched_O = tuple(set(range(O)) - set([i for i, j in match]))
    unmatched_Q = tuple(set(range(Q)) - set([j for i, j in match]))

    return match, unmatched_O, unmatched_Q


def linear_assignment(cost_matrix, thresh):
    if cost_matrix.size == 0:
        return np.empty((0, 2), dtype=int), tuple(range(cost_matrix.shape[0])), tuple(range(cost_matrix.shape[1]))
    matches, unmatched_a, unmatched_b = [], [], []
    # x为一个长度为 N行数的数组，指定每行分配给哪一列
    # y为长度为列数的数组，指定每列分配给哪一行
    # 输入的矩阵不是一个方阵，因此extend_cost为True
    # cost_limit是当指派的值小于这个阈值时才会分配，否则放弃这个分配结果（-1）
    # 没有匹配到的赋值 -1
    # lap.lapjv选择最优的匹配方案  尽可能匹配cost_matrix小的
    # 输出cost指的是 当前匹配方案中计算得到的cost是多少
    cost, x, y = lap.lapjv(cost_matrix, extend_cost=True, cost_limit=thresh)
    for ix, mx in enumerate(x):
        if mx >= 0:
            matches.append([ix, mx])
    # np.where返回对应索引及类型    例： (array([4, 5, 6], dtype=int64),)
    unmatched_a = np.where(x < 0)[0] # u_track
    unmatched_b = np.where(y < 0)[0] # u_det
    matches = np.asarray(matches)
    return matches, unmatched_a, unmatched_b
            

def ious(atlbrs, btlbrs):
    """
    Compute cost based on IoU
    :type atlbrs: list[tlbr] | np.ndarray
    :type atlbrs: list[tlbr] | np.ndarray

    :rtype ious np.ndarray
    """
    ious = np.zeros((len(atlbrs), len(btlbrs)), dtype=np.float)
    if ious.size == 0:
        return ious

    ious = bbox_ious(
        np.ascontiguousarray(atlbrs, dtype=np.float),
        np.ascontiguousarray(btlbrs, dtype=np.float)
    )

    return ious


def iou_distance(atracks, btracks, GIoU=False, DIoU=False, CIoU=False):
    """
    Compute cost based on IoU GIoU DIoU CIoU
    :type atracks: list[STrack]
    :type btracks: list[STrack]

    :rtype cost_matrix np.ndarray
    """
    # ic(atracks), ic(btracks)

    if (len(atracks)>0 and isinstance(atracks[0], np.ndarray)) or (len(btracks) > 0 and isinstance(btracks[0], np.ndarray)):
        atlbrs = atracks
        btlbrs = btracks
    else:
        atlbrs = [track.tlbr for track in atracks]
        btlbrs = [track.tlbr for track in btracks]
        #ic(atlbrs), ic(btlbrs)
    if GIoU or DIoU or CIoU:
        _ious = bbox_iou(atlbrs, btlbrs, GIoU, DIoU, CIoU)
        cost_matrix = 0.5 * (1 - _ious)
        return cost_matrix
    else:
        _ious = ious(atlbrs, btlbrs)
        cost_matrix = 1 - _ious
        return cost_matrix


# used in Sparse SORT 
def bbox_iou(box1, box2, GIoU=False, DIoU=False, CIoU=False):
    # Returns the IoU of box1 to box2. box1 is 4, box2 is nx4
    # box1， box2 = tlbr
    # box1.shape =[num_track, 4]   box2.shape =[num_det, 4] 
    # ious = np.zeros((len(box1), len(box2)), dtype=np.float)
    # if ious.size == 0:
    #     return ious
    box1 = np.array(box1, dtype=np.float)
    box2 = np.array(box2, dtype=np.float)
    iou = np.zeros((len(box1), len(box2)), dtype=np.float)
    if iou.size == 0:
        return iou
    box2 = box2.T

    # Get the coordinates of bounding boxes
      # x1, y1, x2, y2 = box1，box2
    # b1_x1, b1_y1, b1_x2, b1_y2 = box1[:,0], box1[:,1], box1[:,2], box1[:,3]
    # b2_x1, b2_y1, b2_x2, b2_y2 = box2[0,:], box2[1,:], box2[2,:], box2[3,:]
    # box1
    b1_x1 = np.expand_dims(box1[:,0],1).repeat(len(box2[0,:]),axis=1)
    b1_y1 = np.expand_dims(box1[:,1],1).repeat(len(box2[1,:]),axis=1)
    b1_x2 = np.expand_dims(box1[:,2],1).repeat(len(box2[2,:]),axis=1)
    b1_y2 = np.expand_dims(box1[:,3],1).repeat(len(box2[3,:]),axis=1)
    # box2
    b2_x1 = np.expand_dims(box2[0,:],0).repeat(len(box1[:,0]),axis=0)
    b2_y1 = np.expand_dims(box2[1,:],0).repeat(len(box1[:,1]),axis=0)
    b2_x2 = np.expand_dims(box2[2,:],0).repeat(len(box1[:,2]),axis=0)
    b2_y2 = np.expand_dims(box2[3,:],0).repeat(len(box1[:,3]),axis=0)
    # Intersection area


    # inter = (np.min(b1_x2, b2_x2) - np.max(b1_x1, b2_x1)).clamp(0) * \
    #         (np.min(b1_y2, b2_y2) - np.max(b1_y1, b2_y1)).clamp(0)
    inter = (np.minimum(b1_x2, b2_x2) - np.maximum(b1_x1, b2_x1)).clip(0) * \
            (np.minimum(b1_y2, b2_y2) - np.maximum(b1_y1, b2_y1)).clip(0)



    # Union Area
    w1, h1 = b1_x2 - b1_x1, b1_y2 - b1_y1
    w2, h2 = b2_x2 - b2_x1, b2_y2 - b2_y1
    union = (w1 * h1 + 1e-16) + w2 * h2 - inter

    iou = inter / union  # iou
    if GIoU or DIoU or CIoU:
        cw = np.maximum(b1_x2, b2_x2) - np.minimum(b1_x1, b2_x1)  # convex (smallest enclosing box) width
        ch = np.maximum(b1_y2, b2_y2) - np.minimum(b1_y1, b2_y1)  # convex height
        if GIoU:  # Generalized IoU https://arxiv.org/pdf/1902.09630.pdf
            c_area = cw * ch + 1e-16  # convex area
            return iou - (c_area - union) / c_area  # GIoU
        if DIoU or CIoU:  # Distance or Complete IoU https://arxiv.org/abs/1911.08287v1
            # convex diagonal squared
            c2 = cw ** 2 + ch ** 2 + 1e-16
            # centerpoint distance squared
            rho2 = ((b2_x1 + b2_x2) - (b1_x1 + b1_x2)) ** 2 / 4 + ((b2_y1 + b2_y2) - (b1_y1 + b1_y2)) ** 2 / 4
            if DIoU:
                return iou - rho2 / c2  # DIoU
            elif CIoU:  # https://github.com/Zzh-tju/DIoU-SSD-pytorch/blob/master/utils/box/box_utils.py#L47
                v = (4 / math.pi ** 2) * np.power(np.arctan(w2 / h2) - np.arctan(w1 / h1), 2)
                alpha = np.zeros_like(iou)
                for i in range(iou.shape[0]):
                    for j in range(iou.shape[1]):
                        if iou[i][j] >= 0.5:
                            alpha[i][j] = v[i][j] / (1 - iou[i][j] + v[i][j])                                                            
                return iou - (rho2 / c2 + v * alpha)  # CIoU

    return iou



def embedding_distance(tracks, detections, metric='cosine'):
    """
    :param tracks: list[STrack]
    :param detections: list[STrack]
    :param metric:
    :return: cost_matrix np.ndarray
    """

    cost_matrix = np.zeros((len(tracks), len(detections)), dtype=np.float)
    if cost_matrix.size == 0:
        return cost_matrix
    det_features = np.asarray([track.features[-1] for track in detections], dtype=np.float)
    track_features = np.asarray([track.features[-1] for track in tracks], dtype=np.float)
    if metric == 'euclidean':
        # 计算欧氏距离   越小越好
        cost_matrix = np.maximum(0.0, cdist(track_features, det_features)) # Nomalized features
    elif metric == 'cosine':
        # 计算余弦距离    cost_matrix越小越好   cal_cosine_distance越大认为越相似
        cost_matrix = 1. - cal_cosine_distance(track_features, det_features)
    else:
        raise NotImplementedError
    return cost_matrix


def ecu_iou_distance(tracks, detections, img0_shape):
    """
    combine eculidian center-point distance and iou distance
    :param tracks: list[STrack]
    :param detections: list[STrack]
    :param img0_shape: list or tuple, origial (h, w) of frame image

    :rtype cost_matrix np.ndarray  [track_num,detections_num]
    """
    cost_matrix = np.zeros((len(tracks), len(detections)), dtype=np.float)
    if cost_matrix.size == 0:
        return cost_matrix
    
    # calculate eculid dist
    ecu_dist = []
    
    det_bbox = np.asarray([det.tlwh for det in detections])  # shape: (len(detections), 4)
    trk_bbox = np.asarray([trk.tlwh for trk in tracks])  # shape: (len(tracks), 4)
    # 将tlwh转换为xc，yc，w，h
    det_cx, det_cy = det_bbox[:, 0] + 0.5*det_bbox[:, 2], det_bbox[:, 1] + 0.5*det_bbox[:, 3]
    trk_cx, trk_cy = trk_bbox[:, 0] + 0.5*trk_bbox[:, 2], trk_bbox[:, 1] + 0.5*trk_bbox[:, 3]
    for trkIdx in range(len(tracks)):
        # solve center xy
        ecu_dist.append(
            np.sqrt((det_cx - trk_cx[trkIdx])**2 + (det_cy - trk_cy[trkIdx])**2)
        )
    ecu_dist = np.asarray(ecu_dist)# [track_num,detections_num]
    norm_factor = float((img0_shape[0]**2 + img0_shape[1]**2)**0.5)
    ecu_dist = 1. - np.exp(-5*ecu_dist / norm_factor)

    # calculate iou dist  iou_dist = 1-iou
    iou_dist = iou_distance(tracks, detections)
    cost_matrix = 0.5*(ecu_dist + iou_dist)
    return cost_matrix


def cal_cosine_distance(mat1, mat2):
    """
    simple func to calculate cosine distance between 2 matrixs
    
    :param mat1: np.ndarray, shape(M, dim)
    :param mat2: np.ndarray, shape(N, dim)
    :return: np.ndarray, shape(M, N)
    """
    # result = mat1·mat2^T / |mat1|·|mat2|
    # norm mat1 and mat2
    mat1 = mat1 / np.linalg.norm(mat1, axis=1, keepdims=True)
    mat2 = mat2 / np.linalg.norm(mat2, axis=1, keepdims=True)

    return np.dot(mat1, mat2.T)    

def cal_eculidian_distance(mat1, mat2):
    """
    NOTE: another version to cal ecu dist

    simple func to calculate ecu distance between 2 matrixs
    
    :param mat1: np.ndarray, shape(M, dim)
    :param mat2: np.ndarray, shape(N, dim)
    :return: np.ndarray, shape(M, N)
    """
    if len(mat1) == 0 or len(mat2) == 0:
        return np.zeros((len(mat1), len(mat2)))

    mat1_sq, mat2_sq = np.square(mat1).sum(axis=1), np.square(mat2).sum(axis=1)

    # -2ab + a^2 + b^2 = (a-b)^2
    dist = -2 * np.dot(mat1, mat2.T) + mat1_sq[:, None] + mat2_sq[None, :]
    # 将dist的范围限制在0到inf之间
    dist = np.clip(dist, 0, np.inf)

    return np.minimum(0.0, dist.min(axis=0))
    

def fuse_motion(kf, cost_matrix, tracks, detections, only_position=False, lambda_=0.98):
    if cost_matrix.size == 0:
        return cost_matrix
    gating_dim = 2 if only_position else 4
    gating_threshold = kalman_filter.chi2inv95[gating_dim]
    measurements = np.asarray([det.to_xyah() for det in detections])
    for row, track in enumerate(tracks):
        gating_distance = kf.gating_distance(
            track.mean, track.covariance, measurements, only_position, metric='maha')
        cost_matrix[row, gating_distance > gating_threshold] = np.inf
        cost_matrix[row] = lambda_ * cost_matrix[row] + (1-lambda_)* gating_distance
    return cost_matrix


"""
distance metric that combines multi-frame info
used in StrongSORT
TODO: use in DeepSORT
"""

class NearestNeighborDistanceMetric(object):
    """
    A nearest neighbor distance metric that, for each target, returns
    the closest distance to any sample that has been observed so far.

    Parameters
    ----------
    metric : str
        Either "euclidean" or "cosine".
    matching_threshold: float
        The matching threshold. Samples with larger distance are considered an
        invalid match.
    budget : Optional[int]
        If not None, fix samples per class to at most this number. Removes
        the oldest samples when the budget is reached.

    Attributes
    ----------
    samples : Dict[int -> List[ndarray]]
        A dictionary that maps from target identities to the list of samples
        that have been observed so far.

    """

    def __init__(self, metric, matching_threshold, budget=None):
        if metric == "euclidean":
            self._metric = cal_eculidian_distance
        elif metric == "cosine":
            self._metric = cal_cosine_distance
        else:
            raise ValueError(
                "Invalid metric; must be either 'euclidean' or 'cosine'")
        self.matching_threshold = matching_threshold
        self.budget = budget
        self.samples = {}## self.samples记录了每个轨迹的所有外观特征
        self.samples_w = {}##   
        ## 每个track对应的稀疏表示c值  self.samples_w.shape=[track_indx, det_indx, feature_num[track_indx]]  
        # 例：[8,9,3]8个track的3个feature和9个det的feature分别计算稀疏表示c值， 
        self.w_matrix = {} 
             
    def partial_fit(self, features, targets, active_targets):
        """Update the distance metric with new data.

        Parameters
        ----------
        features : ndarray
            An NxM matrix of N features of dimensionality M.
        targets : ndarray
            An integer array of associated target identities.
        active_targets : List[int]
            A list of targets that are currently present in the scene.

        """
        for feature, target in zip(features, targets):
            self.samples.setdefault(target, []).append(feature)
            if self.budget is not None:
                self.samples[target] = self.samples[target][-self.budget:]
        self.samples = {k: self.samples[k] for k in active_targets}

    def distance(self, features, targets):
        """Compute distance between features and targets.

        Parameters
        ----------
        features : ndarray
            An NxM matrix of N features of dimensionality M.
        targets : List[int]
            A list of targets to match the given `features` against.

        Returns
        -------
        ndarray
            Returns a cost matrix of shape len(targets), len(features), where
            element (i, j) contains the closest squared distance between
            `targets[i]` and `features[j]`.

        """
        cost_matrix = np.zeros((len(targets), len(features)))
        for i, target in enumerate(targets):
            cost_matrix[i, :] = self._metric(self.samples[target], features)
        return cost_matrix

    def sparse_distance(self, features, targets):
        """Compute sparse distance between features and targets.

        Parameters
        ----------
        features : ndarray   
            An NxM matrix of N det_features of dimensionality M.
        targets : List[int]   track_id
            A list of targets to match the given `features` against.

        Returns
        -------
        ndarray
            Returns a cost matrix of shape len(targets), len(features), where
            element (i, j) contains the closest squared distance between
            `targets[i]` and `features[j]`.

        """
        cost_matrix = np.zeros((len(targets), len(features)))
        lamb = 0.2
        sigma = 2
        # ic(targets)
        for i, target in enumerate(targets):
            self.w_matrix.setdefault(target, {})
            matrixA = np.array(self.samples[target]).T

            for j, feature in enumerate(features):
                w0 = np.random.rand(matrixA.shape[1], 1)
                vectorb = np.expand_dims(feature, axis=1)
                w, apg_value_new, apg_value_list = nn_APG.APG(w0, matrixA, vectorb, lamb, 10000, 0.01)
                self.w_matrix[target].setdefault(j, [])
                self.w_matrix[target][j] = w
                cost_matrix[i, j] = 1 - np.exp(-1*(apg_value_new**2)/(2*(sigma**2)))  # /(np.sqrt(2 * np.pi) * sigma)

            
        key = [k for k in self.w_matrix]
        # print(targets, features.shape[0])
        # print("nn_matching.轨迹ID", key, len(key))
        # print("nn_matching.代价矩阵大小", cost_matrix.shape)
        return cost_matrix


    def sparse_fit(self, features, targets, active_targets):
        """Update the distance metric with new data.

        Parameters
        ----------
        features : ndarray
            An NxM matrix of N features of dimensionality M.
        targets : ndarray
            An integer array of associated target identities.
        active_targets : List[int]
            A list of targets that are currently present in the scene.

        """
        for feature, target in zip(features, targets):
            self.samples.setdefault(target, []).append(feature) # self.samples记录了每个轨迹的所有外观特征
            self.samples_w.setdefault(target, []) 
            # 删除track中权重小于0.05的特征   self.samples_w[target]=[c1,c2,c3]
            # index_to_delete = [i for i, a in enumerate(self.samples_w[target]) if a < 0.05]
            # 删除track中权重大于delta的特征 
            num_norelated = [True  for b in self.samples_w[target] if b < 0.3]
            if all(num_norelated) and len(num_norelated)!=0:
                del self.samples[target][-1]
            index_to_delete = [i for i, a in enumerate(self.samples_w[target]) if a > 0.65]
            self.samples_w[target] = [self.samples_w[target][i] for i in range(len(self.samples_w[target]))
                                      if i not in index_to_delete]
            self.samples[target] = [self.samples[target][i] for i in range(len(self.samples[target]))
                                      if i not in index_to_delete]  
            # 限制特征个数10
            if len(self.samples[target]) > self.budget:
                self.samples[target] = self.samples[target][-self.budget:]

            # if len(self.samples_w[target]) > self.budget:
            #     self.samples[target] = self.samples[target][-self.budget:]
        self.samples = {k: self.samples[k] for k in active_targets}
     
        


"""
funcs to cal similarity, copied from UAVMOT
"""
def local_relation_fuse_motion(cost_matrix,
                tracks,
                detections,
                only_position=False,
                lambda_=0.98):
    """
    :param kf:
    :param cost_matrix:
    :param tracks:
    :param detections:
    :param only_position:
    :param lambda_:
    :return:
    """

    # print(cost_matrix.shape)
    if cost_matrix.size == 0:
        return cost_matrix

    gating_dim = 2 if only_position else 4
    # gating_threshold = kalman_filter.chi2inv95[gating_dim]
    # measurements = np.asarray([det.tlwh2xyah() for det in detections])
    structure_distance = structure_similarity_distance(tracks,
                                                       detections)
    cost_matrix = lambda_ * cost_matrix + (1 - lambda_) * structure_distance

    return cost_matrix
def structure_similarity_distance(tracks, detections):
    track_structure = structure_representation(tracks)#计算所有点之间的[max_length, min_length, include_angle]
    detection_structure = structure_representation(detections,mode='detection')

    # for debug
    # print(track_structure.shape, detection_structure.shape)
    # exit(0)  cdist()计算cos距离的公式为  1-cos   cost_matrix越小越接近
    cost_matrix = np.maximum(0.0, cdist(track_structure, detection_structure, metric="cosine"))

    return cost_matrix
def angle(v1, v2):
    # dx1 = v1[2] - v1[0]
    # dy1 = v1[3] - v1[1]
    # dx2 = v2[2] - v2[0]
    # dy2 = v2[3] - v2[1]
    dx1 = v1[0]
    dy1 = v1[1]
    dx2 = v2[0]
    dy2 = v2[1]
    angle1 = math.atan2(dy1, dx1)# 得到V1和x轴的夹角弧度值
    angle1 = int(angle1 * 180/math.pi)#转换为角度值
    # print(angle1)
    angle2 = math.atan2(dy2, dx2)
    angle2 = int(angle2 * 180/math.pi)
    # print(angle2)
    if angle1*angle2 >= 0:
        included_angle = abs(angle1-angle2)
    else:
        included_angle = abs(angle1) + abs(angle2)
        if included_angle > 180:
            included_angle = 360 - included_angle
    return included_angle

def structure_representation(tracks,mode='trcak'):
    local_R =400
    structure_matrix =[]
    for i, track_A in enumerate(tracks):
        length = []
        index =[]
        for j, track_B in enumerate(tracks):
            # print(track_A.mean[0:2])
            # pp: 中心点距离  shape: (1, ) 中心点的x方向距离和y方向距离
            if mode =="detection": #map(function, iterable, ...)  将指定序列输入func中计算
                pp = list(
                    map(lambda x: np.linalg.norm(np.array(x[0] - x[1])), zip(track_A.get_xy(), track_B.get_xy())))
            # >>> a = [1,2,3]
            # >>> b = [4,5,6]   zip(a,b)   >>>[(1, 4), (2, 5), (3, 6)]
            else:
                # .mean()是指的track经过卡尔曼滤波预测得到的[x,y,w,h,...]
                pp=list(map(lambda x: np.linalg.norm(np.array(x[0] - x[1])), zip(track_A.mean[0:2],track_B.mean[0:2])))
            lgt = np.linalg.norm(pp)#计算两点之间的距离
            if lgt < local_R and lgt >0:
                length.append(lgt)
                index.append(j)

        if length==[]:
            v =[0.0001,0.0001,0.0001]

        else:
            max_length = max(length)
            min_length = min(length)
            if max_length == min_length:
                v = [max_length, min_length, 0.0001]
            else:
                max_index = index[length.index(max_length)]
                min_index = index[length.index(min_length)]
                if mode == "detection":
                    v1 = tracks[max_index].get_xy() - track_A.get_xy()#将线段移到原点
                    v2 = tracks[min_index].get_xy() - track_A.get_xy()#将线段移到原点
                else:
                    v1 = tracks[max_index].mean[0:2] - track_A.mean[0:2]
                    v2 = tracks[min_index].mean[0:2] - track_A.mean[0:2]

                include_angle = angle(v1, v2)#计算两条线的角度
                v = [max_length, min_length, include_angle]

        structure_matrix.append(v)

    return np.asarray(structure_matrix)



