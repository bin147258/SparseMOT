"""
main code for track
"""
import numpy as np
import torch
import cv2 
from PIL import Image
import tqdm

import argparse
import os
from time import gmtime, strftime
from timer import Timer

from basetrack import BaseTracker  # for framework
from deepsort import DeepSORT
from bytetrack import ByteTrack
from deepmot import DeepMOT
from botsort import BoTSORT
from uavmot import UAVMOT
from strongsort import StrongSORT
from sparsesort import SparseSORT
import trackeval
import yaml
try:  # import package that outside the tracker folder  For yolo v7
    import sys 
    sys.path.append('D:\python\YOLOv7_tracker_master\Yolov7-tracker-master')# 确定工作目录
    #sys.path.append(os.getcwd())# os.getcwd()返回当前的工作目录
    from models.experimental import attempt_load
    # 该工具执行常见的预处理步骤，如特征缩放、一次热编码等，并运行各种ML算法，如随机森林、支持向量机等，然后对每个预处理步骤和ML算法的性能进行评估并给出评分。
    from evaluate import evaluate
    from utils.torch_utils import select_device, time_synchronized, TracedModel
    print('Note: running yolo v7 detector')

except:
    pass

import tracker_dataloader

DATASET_ROOT = './VisDrone2019/VisDrone2019'  # your dataset root

# CATEGORY_NAMES = ['car', 'van', 'truck', 'bus']
CATEGORY_NAMES = ['pedestrain', 'people', 'bicycle', 'car', 'van', 'truck', 'tricycle', 'awning-tricycle', 'bus', 'motor']
CATEGORY_DICT = {i: CATEGORY_NAMES[i] for i in range(len(CATEGORY_NAMES))}  # show class

# IGNORE_SEQS = [] 
IGNORE_SEQS = ['uav0000073_00600_v', 'uav0000088_00290_v','uav0000073_04464_v','uav0000077_00720_v',
               'uav0000119_02301_v','uav0000120_04775_v','uav0000161_00000_v','uav0000188_00000_v',
               'uav0000201_00000_v','uav0000249_00001_v','uav0000249_02688_v','uav0000297_00000_v',
               'uav0000297_02761_v','uav0000306_00230_v','uav0000355_00001_v','uav0000370_00001_v']  # ignore seqs

def set_basic_params(cfgs):
    global CATEGORY_DICT, DATASET_ROOT, CERTAIN_SEQS, IGNORE_SEQS, YAML_DICT
    CATEGORY_DICT = cfgs['CATEGORY_DICT']
    DATASET_ROOT = cfgs['DATASET_ROOT']
    CERTAIN_SEQS = cfgs['CERTAIN_SEQS']
    IGNORE_SEQS = cfgs['IGNORE_SEQS']
    YAML_DICT = cfgs['YAML_DICT']


timer = Timer()
seq_fps = []  # list to store time used for every seq
def main(opts,cfgs):
    set_basic_params(cfgs)  # NOTE: set basic path and seqs params first
    TRACKER_DICT = {
        'sort': BaseTracker,
        'deepsort': DeepSORT,
        'bytetrack': ByteTrack,
        'deepmot': DeepMOT,
        'botsort': BoTSORT,
        'uavmot': UAVMOT, 
        'strongsort': StrongSORT,
        'sparsesort': SparseSORT,  
    }  # dict for trackers, key: str, value: class(BaseTracker)

    # NOTE: ATTENTION: make kalman and tracker compatible
    if opts.tracker == 'botsort':
        opts.kalman_format = 'botsort'
    elif opts.tracker == 'strongsort':
        opts.kalman_format = 'strongsort'

    # NOTE: if save video, you must save image
    if opts.save_videos:
        opts.save_images = True

    """
    1. load model
    """
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # 错误：No module named 'models'   解决办法：给sys.path中添加models所在路径
    ckpt = torch.load(opts.model_path, map_location=device)
    # fuse()是用来进行conv和bn层合并，为了提速模型推理速度。   有repconv层会将repconv融合
    # eval()是模型进行预测推理时关闭BN（预测数据均值方差计算）和Dropout以免影响预测结果。
    # 训练过程中会依据设置的dropout比例会使一部分的网络连接不进行计算,使用model.eval()会使所有网络连接参与计算，显然预测时都参与计算结果会更准确
    # model = ckpt['ema' if ckpt.get('ema') else 'model'].float().fuse()
    model = ckpt['ema' if ckpt.get('ema') else 'model'].float().fuse().eval()  # for yolo v7

    if opts.trace:#多进程跟踪？
        print(opts.img_size)
        model = TracedModel(model, device, opts.img_size)
    else:
        model.to(device)

    """
    2. load dataset and track
    """
    # track per seq
    # firstly, create seq list
    seqs = []
    if opts.data_format == 'yolo':
        with open(f'./{opts.dataset}/test.txt', 'r') as f:
            lines = f.readlines()
            for line in lines:
                # elems=[VisDrone2019,VisDrone2019,images,VisDrone2019-MOT-test-dev,uav0000009_03358_v,0000001.jpg]
                elems = line.split('/')  # devide path by / in order to get sequence name(elems[-2])
                if elems[-2] not in seqs:
                    seqs.append(elems[-2])

    elif opts.data_format == 'origin':
        DATA_ROOT = os.path.join(DATASET_ROOT, 'VisDrone2019-MOT-test-dev/sequences')
        seqs = os.listdir(DATA_ROOT)
    else:
        raise NotImplementedError
    # 将多组视频排序
    seqs = sorted(seqs) # uav0000009_03358_v
    seqs = [seq for seq in seqs if seq not in IGNORE_SEQS]
    print(f'Seqs will be evalueated, total{len(seqs)}:')
    print(seqs)

    # secondly, for each seq, instantiate dataloader class and track
    # every time assign a different folder to store results
    folder_name = strftime("%Y-%d-%m %H:%M:%S", gmtime()) #得到格林尼治时间
    folder_name = folder_name[5:-3].replace('-', '_')
    folder_name = folder_name.replace(' ', '_')
    folder_name = folder_name.replace(':', '_')
    folder_name = opts.tracker + '_' + folder_name

    for seq in seqs:
        print(f'--------------tracking seq {seq}--------------')
        # 若是yolo 路径改为./visdrone/test.txt
        path = os.path.join(DATA_ROOT, seq) if opts.data_format == 'origin' else os.path.join('./', f'{opts.dataset}', 'test.txt')
        # 将图片的宽高、图片位置、图片格式（yolo？）、数据根目录打包
        loader = tracker_dataloader.TrackerLoader(path, opts.img_size, opts.data_format, seq)
        # 分批次
        data_loader = torch.utils.data.DataLoader(loader, batch_size=1)
     
        tracker = TRACKER_DICT[opts.tracker](opts, frame_rate=30, gamma=opts.gamma, use_GMC=True)  # instantiate tracker  TODO: finish init params

        results = []  # store current seq results
        frame_id = 0
        # 返回一个迭代器iterable
        pbar = tqdm.tqdm(desc=f"{seq}", ncols=80)# desc：str类型，作为进度条说明，在进度条左边  ncols：进度条长度，150比较适合
        for i, (img, img0) in enumerate(data_loader):
            pbar.update() # 更新进度条
            timer.tic()  # start timing this img
            # opts.detect_per_frame=1   i=0时  not i % opts.detect_per_frame=True  执行if语句
            # opts.detect_per_frame=1指的是每帧都会检测，然后更新，若等于2时，track会无检测更新一次 再有检测更新一次
            if not i % opts.detect_per_frame:  # if it's time to detect
                # 将图片输入模型   out是tuple型
                # out：(tuple:2) tuple0:[Tensor:(batch_size,detection_num,85)]
                # tuple1:[list:3]   list0:[Tensor:(1,3,80,80,85)],  list1:[Tensor:(1,3,40,40,85)],list2:[Tensor:(1,3,20,20,85)]
                out = model(img.to(device))  # model forward  [xc, yc, w, h]是针对
                # 滤除掉 三个检测头分别检测得到的结果
                out = out[0]  # NOTE: for yolo v7
            
                if len(out.shape) == 3:  # case (bs, num_obj, ...)
                    # out = out.squeeze()
                    # NOTE: assert batch size == 1
                    out = out.squeeze(0)#  [1,25200,85]>>[25200,85]
                    img0 = img0.squeeze(0)# 原图 [1,765,1360,3]>>[765,1360,3]
                # remove some low conf detections
                out = out[out[:, 4] > 0.001]
                
            
                # NOTE: yolo v7 origin out format: [xc, yc, w, h, conf, cls0_conf, cls1_conf, ..., clsn_conf]
                if opts.det_output_format == 'yolo':
                    # 将out=[25200,85]>>[25200,6]  6指的是[xc, yc, w, h, conf,cls]
                    cls_conf, cls_idx = torch.max(out[:, 5:], dim=1)
                    # out[:, 4] *= cls_conf  # fuse object and cls conf
                    out[:, 5] = cls_idx
                    out = out[:, :6]
                # 为第一次检测的框进行nms处理， 并赋予id，为匹配到的框进行更新，删除未匹配的框
                current_tracks = tracker.update(out, img0)  # List[class(STracks)]
            else:  # otherwize
                # make the img shape (bs, C, H, W) as (C, H, W)
                if len(img0.shape) == 4:
                    img0 = img0.squeeze(0)
                """
                update tracks when no detection
                only predict current tracks
                """
                current_tracks = tracker.update_without_detection(None, img0)# 无检测更新
            
            # save results
            cur_tlwh, cur_id, cur_cls = [], [], []
            # 遍历每个跟踪器 得到新id
            for trk in current_tracks:
                bbox = trk.tlwh # [x1,y1,w,h]
                id = trk.track_id
                cls = trk.cls

                # filter low area bbox
                if bbox[2] * bbox[3] > opts.min_area:
                    cur_tlwh.append(bbox)
                    cur_id.append(id)
                    cur_cls.append(cls)
                    # results.append((frame_id + 1, id, bbox, cls))
            # 保存结果
            results.append((frame_id + 1, cur_id, cur_tlwh, cur_cls))
            timer.toc()  # end timing this image
            
            if opts.save_images:
                plot_img(img0, frame_id, [cur_tlwh, cur_id, cur_cls], save_dir=os.path.join(DATASET_ROOT, 'reuslt_images', seq))
        
            frame_id += 1
        # frame/总时间
        seq_fps.append(i / timer.total_time)  # cal fps for current seq
        timer.clear()  # clear for next seq
        pbar.close()
        # thirdly, save results
        # every time assign a different name
        # 建立文件夹./tracker/results/{folder_name}  建立以视频序列为名称的.txt,
        # txt写入的内容为 {frame_id},{id},{tlwh[0]},{tlwh[1]},{tlwh[2]},{tlwh[3]},{int(cls)}\n'
        save_results(folder_name, seq, results)

        ## finally, save videos
        if opts.save_images and opts.save_videos:
            # 将图片转换成视频
            save_videos(seq_names=seq)

    """
    3. evaluate results
    """
    print(f'average fps: {np.mean(seq_fps)}')
    if opts.track_eval:
        default_eval_config = trackeval.Evaluator.get_default_eval_config()
        default_dataset_config = trackeval.datasets.MotChallenge2DBox.get_default_dataset_config()
        yaml_dataset_config = cfgs['TRACK_EVAL']  # read yaml file to read TrackEval configs
        # make sure that seqs is same as 'SEQ_INFO' in yaml
        # delete key in 'SEQ_INFO' which is not in seqs
        seqs_in_cfgs = list(yaml_dataset_config['SEQ_INFO'].keys())
        for k in seqs_in_cfgs:
            if k not in seqs:
                yaml_dataset_config['SEQ_INFO'].pop(k)#从yaml_dataset_config中的SEQ_INFO字典中删除指定的键值对。
        assert len(yaml_dataset_config['SEQ_INFO'].keys()) == len(seqs)
        
        for k in default_dataset_config.keys():
            if k in yaml_dataset_config.keys():  # if the key need to be modified
                default_dataset_config[k] = yaml_dataset_config[k]                

        default_metrics_config = {'METRICS': ['HOTA', 'CLEAR', 'Identity'], 'THRESHOLD': 0.5}
        config = {**default_eval_config, **default_dataset_config, **default_metrics_config}  # Merge default configs
        eval_config = {k: v for k, v in config.items() if k in default_eval_config.keys()}
        dataset_config = {k: v for k, v in config.items() if k in default_dataset_config.keys()}
        metrics_config = {k: v for k, v in config.items() if k in default_metrics_config.keys()}

        # Run code
        evaluator = trackeval.Evaluator(eval_config)
        dataset_list = [trackeval.datasets.MotChallenge2DBox(dataset_config)] if opts.dataset in ['mot', 'uavdt'] else [trackeval.datasets.VisDrone2DBox(dataset_config)]
        metrics_list = []
        for metric in [trackeval.metrics.HOTA, trackeval.metrics.CLEAR, trackeval.metrics.Identity, trackeval.metrics.VACE]:
            if metric.get_name() in metrics_config['METRICS']:
                metrics_list.append(metric(metrics_config))
        if len(metrics_list) == 0:
            raise Exception('No metrics selected for evaluation')
        evaluator.evaluate(dataset_list, metrics_list)  
    else:
        evaluate(sorted(os.listdir(f'./tracker/results/{folder_name}')), 
                    sorted([seq + '.txt' for seq in seqs]), data_type='visdrone', result_folder=folder_name)  



def save_results(folder_name, seq_name, results, data_type='default'):
    """
    write results to txt file

    results: list  row format: frame id, target id, box coordinate, class(optional)
    to_file: file path(optional)
    data_type: write data format
    """
    assert len(results)
    if not data_type == 'default':
        raise NotImplementedError  # TODO

    if not os.path.exists(f'./tracker/results/{folder_name}'):

        os.makedirs(f'./tracker/results/{folder_name}')

    with open(os.path.join('./tracker/results', folder_name, seq_name + '.txt'), 'w') as f:
        for frame_id, target_ids, tlwhs, clses in results:
            if data_type == 'default':

                # f.write(f'{frame_id},{target_id},{tlwh[0]},{tlwh[1]},\
                #             {tlwh[2]},{tlwh[3]},{cls}\n')
                for id, tlwh, cls in zip(target_ids, tlwhs, clses):
                    f.write(f'{frame_id},{id},{tlwh[0]:.2f},{tlwh[1]:.2f},{tlwh[2]:.2f},{tlwh[3]:.2f},{int(cls)}\n')
    f.close()

    return folder_name

def plot_img(img, frame_id, results, save_dir):
    """
    img: np.ndarray: (H, W, C)
    frame_id: int
    results: [tlwhs, ids, clses]
    save_dir: sr

    plot images with bboxes of a seq
    """
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    img_ = np.ascontiguousarray(np.copy(img))

    tlwhs, ids, clses = results[0], results[1], results[2]
    for tlwh, id, cls in zip(tlwhs, ids, clses):

        # convert tlwh to tlbr
        tlbr = tuple([int(tlwh[0]), int(tlwh[1]), int(tlwh[0] + tlwh[2]), int(tlwh[1] + tlwh[3])])
        # draw a rect
        cv2.rectangle(img_, tlbr[:2], tlbr[2:], get_color(id), thickness=3, )
        # note the id and cls
        text = f'{CATEGORY_DICT[cls]}-{id}'
        cv2.putText(img_, text, (tlbr[0], tlbr[1]), fontFace=cv2.FONT_HERSHEY_PLAIN, fontScale=1, 
                        color=(255, 164, 0), thickness=2)

    cv2.imwrite(filename=os.path.join(save_dir, f'{frame_id:05d}.jpg'), img=img_)


def save_videos(seq_names):
    """
    convert imgs to a video

    seq_names: List[str] or str, seqs that will be generated
    """
    if not isinstance(seq_names, list):
        seq_names = [seq_names]

    for seq in seq_names:
        images_path = os.path.join(DATASET_ROOT, 'reuslt_images', seq)
        images_name = sorted(os.listdir(images_path))

        to_video_path = os.path.join(images_path, './', seq + '.mp4')
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")#MPEG-4编码 .mp4 可指定结果视频的大小

        img0 = Image.open(os.path.join(images_path, images_name[0]))
        vw = cv2.VideoWriter(to_video_path, fourcc, 15, img0.size)#cv2.VideoWriter('./result.mp4', f, video_fps, (video_width, video_height))

        for img in images_name:
            if img.endswith('.jpg'):
                frame = cv2.imread(os.path.join(images_path, img))
                vw.write(frame)
    
    print('Save videos Done!!')



def get_color(idx):
    """
    aux func for plot_seq
    get a unique color for each id
    """
    idx = idx * 3
    color = ((37 * idx) % 255, (17 * idx) % 255, (29 * idx) % 255)

    return color

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--dataset', type=str, default='visdrone', help='visdrone, or mot')
    # 数据来源  是原始数据还是yolo格式的数据
    parser.add_argument('--data_format', type=str, default='yolo', help='format of reading dataset')
    # 输出数据格式  yolo或其他
    parser.add_argument('--det_output_format', type=str, default='yolo', help='data format of output of detector, yolo or other')
    # 采用的跟踪器
    parser.add_argument('--tracker', type=str, default='sparsesort', help='sort, deepsort, etc')
    # 权重位置
    parser.add_argument('--model_path', type=str, default='./weights/yolov7.pt', help='model path')
    parser.add_argument('--trace', type=bool, default=False, help='traced model of YOLO v7')
    # 图像尺寸
    parser.add_argument('--img_size', nargs='+', type=int, default=[640, 640], help='[train, test] image sizes')

    """For tracker"""
    # model path
    # reid model
    parser.add_argument('--reid', type=str, default='vision_transformer', help='deepsort_reid, vision_transformer, etc')
    parser.add_argument('--reid_model_path', type=str, default='./weights/vit_person_and_vehicle_reid.pth', help='path for reid model path')
    parser.add_argument('--dhn_path', type=str, default='./weights/DHN.pth', help='path of DHN path for DeepMOT')

    # threshs
    parser.add_argument('--conf_thresh', type=float, default=0.5, help='filter tracks')
    parser.add_argument('--nms_thresh', type=float, default=0.7, help='thresh for NMS')
    parser.add_argument('--iou_thresh', type=float, default=0.5, help='IOU thresh to filter tracks')

    # other options
    parser.add_argument('--track_buffer', type=int, default=30, help='tracking buffer')
    parser.add_argument('--gamma', type=float, default=0.3, help='param to control fusing motion and apperance dist')
    parser.add_argument('--kalman_format', type=str, default='default', help='use what kind of Kalman, default, naive, strongsort or bot-sort like')
    parser.add_argument('--min_area', type=float, default=150, help='use to filter small bboxs')

    parser.add_argument('--save_images', action='store_true', help='save tracking results (image)')
    parser.add_argument('--save_videos', action='store_true', help='save tracking results (video)')

    # detect per several frames
    parser.add_argument('--detect_per_frame', type=int, default=1, help='choose how many frames per detect')
    # Use TrackEval to evaluate
    parser.add_argument('--track_eval', type=bool, default=False, help='Use TrackEval to evaluate')

    # parser.add_argument('--iou_distance', default='True', help='GIoU, DIoU, CIoU')
    
    parser.add_argument("--nn_budget", help="Maximum size of the appearance descriptors "
        "gallery. If None, no budget is enforced.", type=int, default=20)

    opts = parser.parse_args()
    # NOTE: read path of datasets, sequences and TrackEval configs
    with open(f'./tracker/config_files/{opts.dataset}.yaml', 'r') as f:
        cfgs = yaml.load(f, Loader=yaml.FullLoader)
    main(opts, cfgs)
    # for debug
    # evaluate(sorted(os.listdir('./tracker/results/deepmot_17_08_02_38')), 
    #             sorted(os.listdir('./tracker/results/deepmot_17_08_02_38')), data_type='visdrone', result_folder='deepmot_17_08_02_38')  
    # main(opts)
