import time
import pickle
import numpy as np


def lasso_value(matrixA, vectorb, x):
    return np.dot((np.dot(matrixA, x) - vectorb).T, (np.dot(matrixA, x) - vectorb))


def APG(x_k, matrixA, vectorb, lamb, maxiter, epsilon):
    x_kminus1 = x_k
    # 假设实对称矩阵A的特征值为lambda，则ATA的特征值为lambda**2
    eigenvalue, featurevector = np.linalg.eig(np.dot(matrixA.T, matrixA))#计算特征值和特征向量
    l = np.max(eigenvalue)
    value_list = []
    for i in range(1, maxiter + 1):
        value_old = lasso_value(matrixA, vectorb, x_k)
        x_k_hat = x_k + (i - 2) / (i + 1) * (x_k - x_kminus1)
        #         print(np.linalg.norm(x_k-x_kminus1,ord=2))
        x_kminus1 = x_k
        nabla_h = np.dot(matrixA.T, (np.dot(matrixA, x_k_hat) - vectorb))#相当于小论文公式19  求解梯度
        temp_x = x_k_hat - nabla_h / l
        temp = np.zeros(temp_x.shape)
        temp = np.concatenate((np.abs(temp_x) - lamb / l, temp), axis=1)
        x_k = np.sign(temp_x) * np.max(temp, axis=1).reshape(temp_x.shape)#公式23
        value_new = lasso_value(matrixA, vectorb, x_k)
        # if i % 1 == 0:
        #     print("the %dth iter 's value= %f" % (i * 1, value_new[0][0]))
        #         break
        value_list.append(value_new)
        if (abs(value_old[0][0] - value_new[0][0])) <= epsilon:
            return x_k, value_new, value_list
    return x_k, value_new, value_list


if __name__ == '__main__':
    matrixA = np.random.rand(4, 3)
    x_k = np.random.rand(3, 1)
    vectorb = np.random.rand(4, 1)
    lamb = 0.2
    apg_x_k, apg_value_new, apg_value_list = APG(x_k, matrixA, vectorb, lamb, 10000, 0.01)